@extends('welcome')
@section('contant')
    
      <div class="container" >
        <form action="{{ route('practice.update', $practice->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
              <label for="exampleInputEmail1">Name</label>
              <input type="text" class="form-control" value="{{$practice->name}}" id="name1" name="name" aria-describedby="emailHelp" placeholder="Enter name">
              <label for="exampleInputEmail1">Phone Number</label>
              <input type="number" class="form-control" value="{{$practice->phone}}" id="PHNO" name="phone" aria-describedby="emailHelp" placeholder="Enter phone">
              <label for="exampleInputEmail1">Email address</label> 
              <input type="email" name="email" value="{{$practice->email}}" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
              <small id="emailHelp" name="email" class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>
            <div class="form-group form-check">
              <input type="checkbox" class="form-check-input" id="exampleCheck1">
              <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
        <script
            src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
            integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
            crossorigin="anonymous"
        ></script>

        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
            integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
            crossorigin="anonymous"
        ></script>
    </body>
</html>
@endsection
