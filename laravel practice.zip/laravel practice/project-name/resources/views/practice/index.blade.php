@extends('welcome')

@section('contant')
    <div class="container">
        <div>
          <a href="{{route('practice.create')}}">  <button  class="btn btn-success text-end">ADD the Practice</button></a>
        </div>
     <div  class="table-responsive mt-4">
        <table
            class="table table-secondary " >
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone Number</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($practice as $key => $item)
                <tr class="">
                    <td scope="row">{{$key+1}}</td>
                    <td scope="row">{{$item->name}}</td>
                    <td>{{$item->email}}</td>
                    <td>{{$item->phone}}</td>
                    <td><a href="{{ route('practice.edit', $item->id) }}"><button class="btn btn-success">Edit</button></a></td>
                    <form action="{{route('practice.destroy',$item->id)}}" method="POST">
                        @method('Delete')
                        @csrf
                    <td><a delete={{$item->id}}><button class="btn btn-danger me-4" >Delete</button></a></td>
                    </form>
                </tr>
                @endforeach
            </tbody>
        </table>
     </div>
     
    </div>
@endsection

