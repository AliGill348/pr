<?php

use App\Http\Controllers\ClassesController;
use App\Http\Controllers\PracticeController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});
Route::resource('/practice',PracticeController::class);
Route::resource('/Classes',ClassesController::class);
