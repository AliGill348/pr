<?php

namespace App\Http\Controllers;

use App\Models\practice;
use Illuminate\Http\Request;

class PracticeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $practice = practice::all();
        return view("practice.index", compact('practice'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view("practice.create");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // return $request;
        $practice = new practice();
        $practice->name = $request->input('name');
        $practice->email = $request->input('email');
        $practice->phone = $request->input('phone');
        $practice->save();
        return redirect()->route('practice.index')->with('success', 'It is created successfully');
    }

    /**
     * Display the specified resource.
     */
    public function show(practice $practice)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(practice $practice)
    {
        $practice = practice::find($practice->id);
        return view("practice.edit", compact('practice'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, practice $practice)
    {
        $practice->name = $request->input('name');
        $practice->email = $request->input('email');
        $practice->phone = $request->input('phone');
        $practice->save();
        return redirect()->route('practice.index')->with('success', 'It is Updateed successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(practice $practice)
    {
        $practice->delete();
        return redirect()->route('practice.index');
    }
}
