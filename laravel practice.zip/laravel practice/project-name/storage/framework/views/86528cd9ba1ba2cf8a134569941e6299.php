
<?php $__env->startSection('contant'); ?>
    <div class="container">
        <div class="form-group">
            <form action="<?php echo e(route('Classes.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <label for="roomnumber">Room Number</label>
                <input type="number" name="room_no" class="form-control" value="<?php echo e(old('room_no')); ?>">
                <?php if($errors->has('room_no')): ?>
                    <div class="text-danger"><?php echo e($errors->first('room_no')); ?></div>
                <?php endif; ?>

                <label for="roomnumber">Building Number</label>
                <select class="form-control" name="building">
                    <option value="oldbuilding">Old building</option>
                    <option value="newbuilding">New building</option>
                </select>
                <?php if($errors->has('building')): ?>
                    <div class="text-danger"><?php echo e($errors->first('building')); ?></div>
                <?php endif; ?>

                <label for="roomnumber">Assigned Teacher</label>
                <select class="form-control" name="practices_id">
                    <?php $__currentLoopData = $practice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('practices_id')): ?>
                    <div class="text-danger"><?php echo e($errors->first('practices_id')); ?></div>
                <?php endif; ?>

                <div class="d-flex justify-content-center">
                    <button type="submit" class="btn btn-success btn-lg mt-3">Submit</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\laravel practice\project-name\resources\views/Classes/create.blade.php ENDPATH**/ ?>