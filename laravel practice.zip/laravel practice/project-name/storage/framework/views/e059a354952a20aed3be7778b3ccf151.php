

<?php $__env->startSection('contant'); ?>
    <div class="container">
        <div>
          <a href="<?php echo e(route('practice.create')); ?>">  <button  class="btn btn-success text-end">ADD the Practice</button></a>
        </div>
     <div  class="table-responsive mt-4">
        <table
            class="table table-secondary " >
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone Number</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $practice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="">
                    <td scope="row"><?php echo e($key+1); ?></td>
                    <td scope="row"><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->email); ?></td>
                    <td><?php echo e($item->phone); ?></td>
                    <td><a href="<?php echo e(route('practice.edit', $item->id)); ?>"><button class="btn btn-success">Edit</button></a></td>
                    <form action="<?php echo e(route('practice.destroy',$item->id)); ?>" method="POST">
                        <?php echo method_field('Delete'); ?>
                        <?php echo csrf_field(); ?>
                    <td><a delete=<?php echo e($item->id); ?>><button class="btn btn-danger me-4" >Delete</button></a></td>
                    </form>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
     </div>
     
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\laravel practice\project-name\resources\views/practice/index.blade.php ENDPATH**/ ?>