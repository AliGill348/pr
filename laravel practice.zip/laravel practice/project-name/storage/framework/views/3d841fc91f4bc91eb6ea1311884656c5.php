
<?php $__env->startSection('contant'); ?>
    
      <div class="container" >
        <form action="<?php echo e(route('Classes.update', $classes->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <label for="roomnumber" >Room Number</label>
            <input type="number" value="<?php echo e($classes->room_no); ?>" name="room_no" class="form-control" value="">
            <label for="roomnumber">Building Number</label>
            <select class="form-control" name="building" id="">
                <option <?php echo e($classes->building == 'oldbuilding' ? 'selected' : ''); ?> value="oldbuilding">Old building</option>
                <option <?php echo e($classes->building == 'newbuilding' ? 'selected' : ''); ?> value="newbuilding">New building</option>
                
            </select>
            <label for="roomnumber">Assigned Teacher</label>
            <select class="form-control" name="practices_id" id="">
                <?php $__currentLoopData = $practice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($item->id == $classes->id ? 'selected' : '    '); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="d-flex justify-content-center">
                <button type="submit" class="btn btn-success btn-lg mt-3">Submit</button>
            </div>
          </form>
        </div>
        <script
            src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
            integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
            crossorigin="anonymous"
        ></script>

        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
            integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
            crossorigin="anonymous"
        ></script>
    </body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\laravel practice\project-name\resources\views/Classes/edit.blade.php ENDPATH**/ ?>