
<?php $__env->startSection('contant'); ?>
<a href="<?php echo e(route('Classes.create')); ?>">  <button  class="btn btn-success text-end">ADD the Practice</button></a>

<div class="table-responsive  mt-4">
    <table
        class="table table-secondary text-center">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Room No</th>
                <th scope="col">Building</th>
                <th scope="col">Assign Teacher</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="">
                <td scope="row"><?php echo e($key+1); ?></td>
                <td scope="row"><?php echo e($class->room_no); ?></td>
                <td scope="row"><?php echo e($class->building); ?></td>
                <?php if(isset($class->practice)): ?>
                <td scope="row"><?php echo e($class->practice->name); ?></td>
                <?php endif; ?>
                <td><a href="<?php echo e(route('Classes.edit', $class->id)); ?>"><button class="btn btn-success">Edit</button></a></td>
                <form action="<?php echo e(route('Classes.destroy',$class->id)); ?>" method="POST">
                    <?php echo method_field('Delete'); ?>
                    <?php echo csrf_field(); ?>
                <td><a delete=<?php echo e($class->id); ?>><button class="btn btn-danger me-4" >Delete</button></a></td>
                </form>            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\laravel practice\project-name\resources\views/Classes/index.blade.php ENDPATH**/ ?>